package com.example.individualprojectpicpix;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper1 extends SQLiteOpenHelper {

    // Database details
    private static final String DB_NAME = "PicFixDatabase138";
    private static final int DB_VERSION = 1;

    // Table names
    private static final String TABLE_CUSTOMER_DETAILS = "customerDetails";
    private static final String TABLE_FIND_SERVICER = "findService";
    //private static final String TABLE_FEEDBACK = "feedback";
    private static final String TABLE_EMPLOYEE_DETAILS = "employeeDetails";
    private static final String TABLE_ADD_SERVICING = "Done_Servicing";

    // Common column names
    private static final String COLUMN_ID = "id";

    // Customer Details table column names
    private static final String COLUMN_USER_NAME = "name";
    private static final String COLUMN_USER_CONTACT = "contact";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PASSWORD = "password";


    // Find Servicer table column names
    private static final String COLUMN_VEHICLE_NUMBER = "vehicleNumber";
    private static final String COLUMN_VEHICLE_MODEL = "vehicleModel";
    private static final String COLUMN_VEHICLE_COLOR = "vehicleColor";
    private static final String COLUMN_BN_DETAILS = "bnDetails";
    private static final String COLUMN_LATITUDE = "latitude";
    private static final String COLUMN_LONGITUDE = "longitude";



    //////////////////////
    //Customer Feedback table column name
    private static final String COLUMN_FEEDBACK = "Feedback";

    // EMPLOYEE Details table column names
    private static final String COLUMN_EMPLOYEE_NAME = "name";
    private static final String COLUMN_EMPLOYEE_CONTACT = "contact";
    private static final String COLUMN_EMPLOYEE_EMAIL = "email";
    private static final String COLUMN_EMPLOYEE_PASSWORD = "password";
    private static final String COLUMN_IMAGE_URI = "image_uri";

    // Add_Servicing  table column names
    private static final String COLUMN_SERVICE_VEHICLE_NUMBER = "vehicle_number";
    private static final String COLUMN_SERVICE_VEHICLE_MODEL = "vehicle_model";
    private static final String COLUMN_SERVICEcus_NAME = "customer_name";
    private static final String COLUMN_SERVICE_DES = "whatDid";
    private static final String COLUMN_SERVICE_CHARGE = "charge";
    // Constructor
    public DatabaseHelper1(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Customer Details table
        String createCustomerTableQuery = "CREATE TABLE " + TABLE_CUSTOMER_DETAILS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USER_NAME + " TEXT, "
                + COLUMN_USER_CONTACT + " TEXT, "
                + COLUMN_USER_EMAIL + " TEXT, "
                + COLUMN_USER_PASSWORD + " TEXT, "
                + COLUMN_FEEDBACK + " TEXT, "
                + COLUMN_VEHICLE_NUMBER + " TEXT, "
                + COLUMN_VEHICLE_MODEL + " TEXT, "
                + COLUMN_VEHICLE_COLOR + " TEXT, "
                + COLUMN_BN_DETAILS + " TEXT, "
                + COLUMN_LATITUDE + " TEXT, "
                + COLUMN_LONGITUDE + " TEXT)";


               db.execSQL(createCustomerTableQuery);

//        // Create Find Service table
//        String createFindServiceTableQuery = "CREATE TABLE " + TABLE_FIND_SERVICER + "("
//                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
//                + COLUMN_VEHICLE_NUMBER + " TEXT, "
//                + COLUMN_VEHICLE_MODEL + " TEXT, "
//                + COLUMN_VEHICLE_COLOR + " TEXT, "
//                + COLUMN_BN_DETAILS + " TEXT, "
//                + COLUMN_LOCATION + " TEXT)";
//        db.execSQL(createFindServiceTableQuery);

        // Create Employee Details table
        String create_employeeDetailsTableQuery = "CREATE TABLE " + TABLE_EMPLOYEE_DETAILS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_EMPLOYEE_NAME + " TEXT, "
                + COLUMN_EMPLOYEE_CONTACT + " TEXT, "
                + COLUMN_EMPLOYEE_EMAIL + " TEXT, "
                + COLUMN_EMPLOYEE_PASSWORD + " TEXT, "
                + COLUMN_IMAGE_URI + " TEXT, "
                + COLUMN_SERVICE_VEHICLE_NUMBER + " TEXT, "
                + COLUMN_SERVICE_VEHICLE_MODEL + " TEXT, "
                + COLUMN_SERVICEcus_NAME + " TEXT, "
                + COLUMN_SERVICE_DES + " TEXT, "
                + COLUMN_SERVICE_CHARGE + " TEXT)";

        db.execSQL(create_employeeDetailsTableQuery);

//      //CREATE ADD SERVICING TABLE
//        String create_addServicingTableQuery = "CREATE TABLE " + TABLE_ADD_SERVICING + "("
//                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
//                + COLUMN_SERVICE_VEHICLE_NUMBER + " TEXT, "
//                + COLUMN_SERVICE_VEHICLE_MODEL + " TEXT, "
//                + COLUMN_SERVICEcus_NAME + " TEXT, "
//                + COLUMN_SERVICE_DES + " TEXT, "
//                + COLUMN_SERVICE_CHARGE + " TEXT)";
//        db.execSQL(create_addServicingTableQuery);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CUSTOMER_DETAILS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FIND_SERVICER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEE_DETAILS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADD_SERVICING);

        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_FEEDBACK);


        // Recreate tables
        onCreate(db);
    }

    // Methods for interacting with Customer Details table
    public void addNewCustomer(String customerName, String customerContact, String customerEmail, String customerPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, customerName);
        values.put(COLUMN_USER_CONTACT, customerContact);
        values.put(COLUMN_USER_EMAIL, customerEmail);
        values.put(COLUMN_USER_PASSWORD, customerPassword);

        db.insert(TABLE_CUSTOMER_DETAILS, null, values);
        db.close();
    }

    public boolean checkLoginUSer(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_EMAIL};
        String selection = COLUMN_USER_EMAIL + "=? AND " + COLUMN_USER_PASSWORD + "=?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(TABLE_CUSTOMER_DETAILS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }
    public boolean checkLoginEmployee(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_EMPLOYEE_EMAIL};
        String selection = COLUMN_EMPLOYEE_EMAIL + "=? AND " + COLUMN_EMPLOYEE_PASSWORD + "=?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(TABLE_EMPLOYEE_DETAILS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    // Methods for interacting with Find Service table
    public boolean addFindService(String vehicleNumber, String vehicleModel, String vehicleColor, String bnDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_VEHICLE_NUMBER, vehicleNumber);
        values.put(COLUMN_VEHICLE_MODEL, vehicleModel);
        values.put(COLUMN_VEHICLE_COLOR, vehicleColor);
        values.put(COLUMN_BN_DETAILS, bnDetails);


        long result = db.insert(TABLE_CUSTOMER_DETAILS, null, values);
        db.close();

        return result != -1; // Returns true if insertion was successful, false otherwise
    }

    public boolean addlocationData(String latitude, String longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_LATITUDE , latitude);
        values.put(COLUMN_LONGITUDE , longitude);
        long result = db.update(TABLE_CUSTOMER_DETAILS, values, COLUMN_ID + "=1", null);
        db.close();
        return result != -1;
    }
    public void addFeedBack(String txtFeedBack) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FEEDBACK, txtFeedBack);
        db.update(TABLE_CUSTOMER_DETAILS, values, COLUMN_ID + "=1", null); // Assuming you want to update the feedback for the first customer
        db.close();
    }


    public void addNewEmployee(String employeeName, String employeeContact, String employeeEmail, String employeePassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMPLOYEE_NAME, employeeName);
        values.put(COLUMN_EMPLOYEE_CONTACT, employeeContact);
        values.put(COLUMN_EMPLOYEE_EMAIL, employeeEmail);
        values.put(COLUMN_EMPLOYEE_PASSWORD, employeePassword);

        db.insert(TABLE_EMPLOYEE_DETAILS, null, values);
        db.close();
    }

    public void addEmployeeImage(String imageUriString) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("image_uri", imageUriString);
        db.update(TABLE_EMPLOYEE_DETAILS, values, COLUMN_ID + "=1", null); // Assuming you want to update the feedback for the first customer
        db.close();
    }

    public void addNewServicing(String vehicleNameString, String vehicleModelString, String customerNameString, String whatDidString, String chargeString) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SERVICE_VEHICLE_NUMBER, vehicleNameString);
        values.put(COLUMN_SERVICE_VEHICLE_MODEL, vehicleModelString);
        values.put(COLUMN_SERVICEcus_NAME, customerNameString);
        values.put(COLUMN_SERVICE_DES,  whatDidString);
        values.put(COLUMN_SERVICE_CHARGE, chargeString);

        db.update(TABLE_EMPLOYEE_DETAILS, values, COLUMN_ID + "=1", null); // Assuming you want to update the feedback for the first customer
        db.close();
    }

    // Method to retrieve data from the database

    // Method to retrieve data from the database
    public ArrayList<String> getCustomerByEmail(String email) {
        ArrayList<String> customerDetails = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String selection = COLUMN_USER_EMAIL + "=?";
        String[] selectionArgs = { email };
        Cursor cursor = db.query(TABLE_CUSTOMER_DETAILS, null, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                StringBuilder rowData = new StringBuilder();
                int columnCount = cursor.getColumnCount();
                for (int i = 0; i < columnCount; i++) {
                    String columnName = cursor.getColumnName(i);
                    String columnValue = cursor.getString(i);
                    rowData.append(columnName).append(": ").append(columnValue).append("\n");
                }
                customerDetails.add(rowData.toString());
            } while (cursor.moveToNext());
            cursor.close();
        }
        return customerDetails;
    }


    public void deleteCustomerByEmail(String email) {
        SQLiteDatabase db = getWritableDatabase();
        String whereClause = COLUMN_USER_EMAIL + "=?";
        String[] whereArgs = { email };
        db.delete(TABLE_CUSTOMER_DETAILS, whereClause, whereArgs);
    }

    public ArrayList<String> getEmployeeByEmail(String email) {
        ArrayList<String> customerDetails = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String selection = COLUMN_EMPLOYEE_EMAIL + "=?";
        String[] selectionArgs = { email };
        Cursor cursor = db.query(TABLE_EMPLOYEE_DETAILS, null, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                StringBuilder rowData = new StringBuilder();
                int columnCount = cursor.getColumnCount();
                for (int i = 0; i < columnCount; i++) {
                    String columnName = cursor.getColumnName(i);
                    String columnValue = cursor.getString(i);
                    rowData.append(columnName).append(": ").append(columnValue).append("\n");
                }
                customerDetails.add(rowData.toString());
            } while (cursor.moveToNext());
            cursor.close();
        }
        return customerDetails;
    }


}
