package com.example.individualprojectpicpix;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class customerLocation extends AppCompatActivity {

    private EditText editTextLatitude;
    private EditText editTextLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_location);

        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitude);
        Button openMapsButton = findViewById(R.id.button_open_maps);
        openMapsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGoogleMaps();
            }
        });
    }

    private void openGoogleMaps() {
        String latitude = editTextLatitude.getText().toString();
        String longitude = editTextLongitude.getText().toString();

        if (latitude.isEmpty() || longitude.isEmpty()) {
            // Handle case where latitude or longitude is not provided
            return;
        }

        // Google Maps URI for a specific location based on latitude and longitude
        Uri gmmIntentUri = Uri.parse("geo:" + latitude + "," + longitude);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Handle scenario where Google Maps app is not installed
            // You can prompt the user to install Google Maps from the Play Store
        }
    }

    public void openHome(View view) {
        startActivity(new Intent(customerLocation.this, employeeHome.class));

    }

    public void goBack(View view) {
        startActivity(new Intent(customerLocation.this, viewCustomerDetails.class));
    }
}