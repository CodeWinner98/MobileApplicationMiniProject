package com.example.individualprojectpicpix;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

public class welcomeActivity extends AppCompatActivity {

    private static final int MAX_PROGRESS = 250;
    private static final int PROGRESS_DELAY = 50; // milliseconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        final ProgressBar progressBar = findViewById(R.id.progressBar2);

        // Set up progress tracking
        progressBar.setMax(MAX_PROGRESS);

        // Simulate progress
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            int progress = 0;

            @Override
            public void run() {
                if (progress <= MAX_PROGRESS) {
                    progressBar.setProgress(progress);
                    progress++;
                    handler.postDelayed(this, PROGRESS_DELAY);
                } else {
                    // Progress is fully loaded, transition to home activity
                    startActivity(new Intent(welcomeActivity.this, welcome2.class));
                    finish(); // Optionally finish current activity
                }
            }
        }, PROGRESS_DELAY);
    }
}

