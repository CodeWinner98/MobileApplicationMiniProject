package com.example.individualprojectpicpix;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class getLocation extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private TextView textLatitude, textLongitude;
    private Button  getLocationButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_location);

        textLatitude= findViewById(R.id.textLatitude);
        textLongitude= findViewById(R.id.textLongitude);
        getLocationButton = findViewById(R.id.button_get_location);

        getLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestLocationPermission();
            }
        });
    }

    private void requestLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            getLocation();
        }
    }

    private void getLocation() {
        // Check if the permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // Access to the location has been granted
            // Get the user's last known location
            // Note: This may return null if location is unavailable
            // You might want to handle this case appropriately
            // For production use, consider using a fused location provider for more robust location updates
            // Here, we are just demonstrating how to get the last known location
            // and display it as latitude and longitude
            android.location.LocationManager locationManager = (android.location.LocationManager) getSystemService(LOCATION_SERVICE);
            Location lastKnownLocation = locationManager.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);
            if (lastKnownLocation != null) {
                double latitude = lastKnownLocation.getLatitude();
                double longitude = lastKnownLocation.getLongitude();
                textLatitude.setText(latitude + ", ");
                textLongitude.setText(longitude + ", ");


                // Add latitude and longitude to database
                addLocationToDatabase(latitude, longitude);

            } else {
                // Handle the case where the last known location is not available
                textLatitude.setText("Current Location: Unknown");
                textLongitude.setText("Current Location: Unknown");
            }
        }
    }

    private void addLocationToDatabase(double latitude, double longitude) {
        // Assuming you have a SQLite database helper class named DatabaseHelper
        DatabaseHelper1 dbHelper = new DatabaseHelper1(this);

        // Insert latitude and longitude into the database
        boolean inserted = dbHelper.addlocationData(String.valueOf(latitude), String.valueOf(longitude));

        if (inserted) {
            // Data added successfully
            // You can display a toast or perform any other action if needed
        } else {
            // Failed to add data
            // You can display a toast or perform any other action if needed
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted, yay! Do the location-related task you need to do.
                getLocation();
            } else {
                // Permission denied, boo! Disable the functionality that depends on this permission.
                // You can show a dialog here or request permission again or handle as you want.
            }
        }
    }

    public void back(View view) {
        startActivity(new Intent(getLocation.this, findServicer.class));
    }
    public void next(View view) {
        startActivity(new Intent(getLocation.this, cusFeedback.class));
    }
}
