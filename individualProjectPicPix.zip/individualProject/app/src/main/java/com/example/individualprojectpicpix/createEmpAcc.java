package com.example.individualprojectpicpix;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class createEmpAcc extends AppCompatActivity {
    private EditText employeeNameEdt, employeeContactEdt, employeeEmailEdt, employeePasswordEdt;
    private Button addEmpBtn;
    private DatabaseHelper1 dbHandler;
    private static final int PICK_IMAGE_REQUEST = 1;
    private Button btnUpload;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_emp_acc);

        addEmpBtn = findViewById(R.id.btnSignUp);
        employeeNameEdt = findViewById(R.id.txtName);
        employeeContactEdt = findViewById(R.id.txtPhone);
        employeeEmailEdt = findViewById(R.id.txtEmail);
        employeePasswordEdt = findViewById(R.id.txtpwd);

        // creating a new DBHandler instance
        // and passing our context to it.
        dbHandler = new DatabaseHelper1(createEmpAcc.this);

        addEmpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getting data from all EditText fields.
                String employeeName = employeeNameEdt.getText().toString();
                String employeeContact = employeeContactEdt.getText().toString();
                String employeeEmail = employeeEmailEdt.getText().toString();
                String employeePassword = employeePasswordEdt.getText().toString();
                String name = "Name";
                String contact = "Contact";
                String password = "Password";
                String email = "Email";

                // validating if the fields are empty or not.
                if (employeeName.isEmpty() || employeeContact.isEmpty() ||employeeEmail.isEmpty() || employeePassword.isEmpty()) {
                    Toast.makeText(createEmpAcc.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (employeeName.equals(name) || employeeContact.equals(contact) || employeeEmail.equals(password) || employeePassword.equals(email)) {
                    Toast.makeText(createEmpAcc.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // adding new customer to SQLite database.
                dbHandler.addNewEmployee(employeeName, employeeContact, employeeEmail, employeePassword);

                // displaying a toast message after adding the customer.
                Toast.makeText(createEmpAcc.this, "Customer has been added.", Toast.LENGTH_SHORT).show();

                // clearing all EditText fields after adding customer.
                employeeNameEdt.setText("");
                employeeContactEdt.setText("");
                employeeEmailEdt.setText("");
                employeePasswordEdt.setText("");

                startActivity(new Intent(createEmpAcc.this, loginEmployee.class));
            }
        });

    }

    public void reload(View view) {
        recreate();
    }

    public void loginButton(View view) {
        startActivity(new Intent(createEmpAcc.this, loginEmployee.class));
    }

    // creating a new DBHandler instance
    // and passing our context to it.





}